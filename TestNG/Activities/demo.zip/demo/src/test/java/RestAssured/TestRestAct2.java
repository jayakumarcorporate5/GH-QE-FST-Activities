package RestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TestRestAct2 {

    @Test(priority = 1)
    public void addNewUserFromFile() throws IOException {

        // ✅ Correct path to JSON file
        FileInputStream inputJSON =
                new FileInputStream("src/test/resources/userInfo.json");

        Response response =
            given()
                .baseUri("https://petstore.swagger.io/v2")
                .contentType(ContentType.JSON)
                .body(inputJSON)
            .when()
                .post("/user");

        inputJSON.close();

        // ✅ Assertions
        response.then()
                .statusCode(200)
                .body("code", equalTo(200))
                .body("message", equalTo("9901"));
    }

    @Test(priority = 2)
    public void getUserInfo() throws IOException {

        File outputJSON =
                new File("src/test/resources/userGETResponse.json");

        Response response =
            given()
                .baseUri("https://petstore.swagger.io/v2")
                .contentType(ContentType.JSON)
                .pathParam("username", "justinc")
            .when()
                .get("/user/{username}");

        // ✅ Write response to file
        String resBody = response.getBody().asPrettyString();
        FileWriter writer = new FileWriter(outputJSON);
        writer.write(resBody);
        writer.close();

        // ✅ Assertions
        response.then()
                .statusCode(200)
                .body("id", equalTo(9901))
                .body("username", equalTo("justinc"))
                .body("firstName", equalTo("Justin"))
                .body("lastName", equalTo("Case"))
                .body("email", equalTo("justincase@mail.com"))
                .body("password", equalTo("password123"))
                .body("phone", equalTo("9812763450"));
    }

    @Test(priority = 3)
    public void deleteUser() {

        Response response =
            given()
                .baseUri("https://petstore.swagger.io/v2")
                .contentType(ContentType.JSON)
                .pathParam("username", "justinc")
            .when()
                .delete("/user/{username}");

        // ✅ Assertions
        response.then()
                .statusCode(200)
                .body("code", equalTo(200))
                .body("message", equalTo("justinc"));
    }
}