package RestAssured;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.testng.Reporter;
import org.testng.annotations.Test;

import io.restassured.response.Response;

public class TestRestAct3 {

    int petId;

    @Test(priority = 1)
    public void addNewPet() {

        Reporter.log("Adding a new pet (POST request)", true);

        petId = new Random().nextInt(100000);

        Map<String, Object> reqBody = new HashMap<>();
        reqBody.put("id", petId);
        reqBody.put("name", "Bruno");
        reqBody.put("status", "available");

        Response response = given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .header("Content-Type", "application/json")
                .body(reqBody)
                .when()
                .post();

        Reporter.log("Pet created with ID: " + petId, true);

        response.then()
                .statusCode(200)
                .body("id", equalTo(petId))
                .body("name", equalTo("Bruno"))
                .body("status", equalTo("available"));
    }

    @Test(priority = 2)
    public void getPetDetails() {

        Reporter.log("Fetching pet details (GET request)", true);

        given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .pathParam("petId", petId)
                .when()
                .get("/{petId}")
                .then()
                .statusCode(200)
                .body("id", equalTo(petId));
    }

    @Test(priority = 3)
    public void updatePetStatus() {

        Reporter.log("Updating pet status (PUT request)", true);

        Map<String, Object> reqBody = new HashMap<>();
        reqBody.put("id", petId);
        reqBody.put("name", "Bruno");
        reqBody.put("status", "sold");

        given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .header("Content-Type", "application/json")
                .body(reqBody)
                .when()
                .put()
                .then()
                .statusCode(200)
                .body("status", equalTo("sold"));

        Reporter.log("Pet status updated to SOLD", true);
    }

    @Test(priority = 4)
    public void verifyUpdatedStatus() {

        Reporter.log("Verifying updated pet status (GET request)", true);

        given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .pathParam("petId", petId)
                .when()
                .get("/{petId}")
                .then()
                .statusCode(200)
                .body("status", equalTo("sold"));
    }

    @Test(priority = 5)
    public void deletePet() {

        Reporter.log("Deleting pet (DELETE request)", true);

        given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .pathParam("petId", petId)
                .when()
                .delete("/{petId}")
                .then()
                .statusCode(200);

        Reporter.log("Pet deleted successfully", true);
    }

    @Test(priority = 6)
    public void verifyPetNotFound() {

        Reporter.log("Verifying pet is not found after deletion", true);

        given()
                .baseUri("https://petstore.swagger.io/v2/pet")
                .pathParam("petId", petId)
                .when()
                .get("/{petId}")
                .then()
                .statusCode(404);
    }
}