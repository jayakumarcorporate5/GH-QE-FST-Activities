package RestAssured;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class TestIPApi {

    @Test
    public void getIPInformation() {

        // ✅ Base URL with path parameter placeholder
        String ROOT_URI = "http://ip-api.com/json/{ipAddress}";

        // ✅ Execute request
        Response response =
            given()
                .contentType(ContentType.JSON)
                .pathParam("ipAddress", "107.218.134.107")
            .when()
                .get(ROOT_URI);

        // ✅ Print response
        System.out.println(response.getBody().asPrettyString());

        // ✅ Basic assertion
        response.then().statusCode(200);
    }
}