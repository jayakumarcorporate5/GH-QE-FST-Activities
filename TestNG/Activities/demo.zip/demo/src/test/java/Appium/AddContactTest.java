package Appium;

import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.*;
import org.testng.annotations.*;

import io.appium.java_client.android.AndroidDriver;

public class AddContactTest {

    AndroidDriver driver;
    WebDriverWait wait;

    @BeforeTest
    public void setUp() throws Exception {

        DesiredCapabilities caps = new DesiredCapabilities();

        caps.setCapability("platformName", "Android");

        // ✅ W3C FIX
        caps.setCapability("appium:deviceName", "Android Device");
        caps.setCapability("appium:automationName", "UiAutomator2");
        caps.setCapability("appium:appPackage", "com.google.android.contacts");
        caps.setCapability("appium:appActivity", "com.android.contacts.activities.PeopleActivity");

        driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), caps);

        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    @Test
    public void addNewContactTest() {

        // 🔹 Click Add Contact
        wait.until(ExpectedConditions.elementToBeClickable(
                By.id("com.google.android.contacts:id/floating_action_button")))
                .click();

        // 🔹 First Name
        WebElement firstName = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//android.widget.EditText[@text='First name']")));
        firstName.sendKeys("Jaya");

        // 🔹 Last Name
        WebElement lastName = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.xpath("//android.widget.EditText[@text='Last name']")));
        lastName.sendKeys("Kumar");

        // 🔥 Phone (CORRECT FIX — NO INDEX ISSUE)
        WebElement phone = wait.until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.id("com.google.android.contacts:id/phone")));
        phone.sendKeys("9876543210");

        // 🔹 Save Contact
        WebElement saveBtn = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.id("com.google.android.contacts:id/editor_menu_save_button")));
        saveBtn.click();

        System.out.println("✅ Contact Added Successfully");
    }

    @AfterTest
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }
}