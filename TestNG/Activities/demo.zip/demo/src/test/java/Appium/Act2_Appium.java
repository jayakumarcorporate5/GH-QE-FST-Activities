package Appium;

import java.net.URL;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

import java.time.Duration;

public class Act2_Appium {

    AndroidDriver driver;
    WebDriverWait wait;

    @BeforeClass
    public void setUp() throws Exception {

        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("Android");
        options.setAutomationName("UiAutomator2");

        // Chrome
        options.setAppPackage("com.android.chrome");
        options.setAppActivity("com.google.android.apps.chrome.Main");
        options.noReset();   // Appium 9.x

        driver = new AndroidDriver(
                new URL("http://localhost:4723"),
                options
        );

        wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Open website
        driver.get("https://training-support.net");
    }

    @Test
    public void chromeTest() throws InterruptedException {

        // Wait a bit for page render (Chrome native rendering delay)
        Thread.sleep(4000);

        // ✅ Flexible native locator
        String heading = driver.findElement(
                AppiumBy.androidUIAutomator(
                        "new UiSelector().textContains(\"Training\")"
                )
        ).getText();

        System.out.println("Heading: " + heading);

        // Click About Us
        driver.findElement(
                AppiumBy.androidUIAutomator(
                        "new UiSelector().textContains(\"About\")"
                )
        ).click();

        Thread.sleep(3000);

        String aboutHeading = driver.findElement(
                AppiumBy.androidUIAutomator(
                        "new UiSelector().textContains(\"About\")"
                )
        ).getText();

        System.out.println("About page heading: " + aboutHeading);
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}