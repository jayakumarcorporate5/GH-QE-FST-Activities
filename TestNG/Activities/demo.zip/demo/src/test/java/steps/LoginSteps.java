package steps;

import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseClass {

    @Given("the user is on the login page")
    public void openPage() {
        driver.get("https://training-support.net/webelements/login-form");
        Assertions.assertEquals("Selenium: Login Form", driver.getTitle());
    }

    @When("the user enters {string} and {string}")
    public void enterCredentialsFromInputs(String username, String password) {
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));

        usernameField.clear();
        passwordField.clear();

        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
    }

    @And("clicks the submit button")
    public void clickSubmit() {
        driver.findElement(By.xpath("//button[text()='Submit']")).click();
    }

    // ✅ THIS IS THE ONLY METHOD THAT NEEDED FIXING
    @Then("get the confirmation text and verify message as {string}")
    public void confirmMessageAsInput(String expectedMessage) {

        // For invalid login, message appears here:
        String actualMessage = wait.until(
            ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("h2#subheading")
            )
        ).getText();

        Assertions.assertEquals(expectedMessage, actualMessage);
    }
}