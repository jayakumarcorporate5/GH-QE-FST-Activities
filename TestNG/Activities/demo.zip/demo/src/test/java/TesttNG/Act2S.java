package TesttNG;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;
// import java.util.function.Function;

public class Act2S {
    private WebDriver driver;
    private FluentWait<WebDriver> wait;

    // You can toggle which URL to open for this activity.
    // 1) Classic page with well-known "Black" button:
    private static final String V1_URL = "https://v1.training-support.net/selenium/target-practice";
    // 2) Your original activity page (DOM may differ):
    private static final String WEBELEMENTS_URL = "https://training-support.net/webelements/target-practice/";

    // Pick the URL you want to use:
    private static final String BASE_URL = V1_URL; // or WEBELEMENTS_URL

    @BeforeClass
    public void setUp() {
        driver = new FirefoxDriver();
        wait = new FluentWait<>(driver)
                .withTimeout(Duration.ofSeconds(15))
                .pollingEvery(Duration.ofMillis(400))
                .ignoring(NoSuchElementException.class)
                .ignoring(StaleElementReferenceException.class);

        driver.get(BASE_URL);

        // Both pages contain "Target Practice" in the title.
        wait.until((ExpectedCondition<Boolean>) d -> d != null && d.getTitle() != null
                && d.getTitle().contains("Target Practice"));
    }

    @Test(priority = 1)
    public void testCase1_getTitle_shouldPass() {
        // PASS: assert title. Different pages use slightly different full titles.
        String title = driver.getTitle();
        System.out.println("Title is: " + title);

        // Accept either exact "Selenium: Target Practice" (webelements page)
        // or "Target Practice" (v1 page).
        boolean ok = "Selenium: Target Practice".equals(title) || "Target Practice".equals(title);
        Assert.assertTrue(ok, "Unexpected page title: " + title);
    }

    @Test(priority = 2)
    public void testCase2_findBlackButton_makeIncorrectAssertion_shouldFail() {
        // Strategy: try multiple robust locators until one resolves.
        // On the classic v1 page, the control is a Semantic-UI styled button-like element.
        List<By> candidates = Arrays.asList(
                By.id("black"),                                  // if element has id=black
                By.cssSelector(".ui.black.button"),              // Semantic UI button classes
                By.xpath("//*[self::button or self::a][contains(@class,'black')]"), // tag-agnostic
                By.xpath("//*[normalize-space(text())='Black']") // last resort by visible text
        );

        WebElement blackButton = findFirstPresentAndVisible(candidates, Duration.ofSeconds(12));

        // Optional scroll into view (helps in headful/headless rendering differences)
        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].scrollIntoView({block:'center'});", blackButton);

        Assert.assertTrue(blackButton.isDisplayed(), "Black control is not displayed.");

        // ❌ Intentionally wrong assertion to force a FAIL (case mismatch):
        String actualText = blackButton.getText().trim();
        Assert.assertEquals(actualText, "black",
                "Intentionally incorrect text check to force a failure. Actual: " + actualText);
    }

    // Disabled test: will NOT run or show as skipped
    @Test(priority = 3, enabled = false)
    public void testCase3_disabled_notShownAsSkipped() {
        String subHeading = driver.findElement(By.className("sub")).getText();
        Assert.assertTrue(subHeading.contains("Practice"));
    }

    // Skipped test: will be reported as SKIPPED in TestNG reports
    @Test(priority = 4)
    public void testCase4_skipByThrowingSkipException_shouldShowAsSkipped() {
        throw new SkipException("Skipping test case intentionally using SkipException");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            // As per the activity requirement:
            driver.close();  // closes the current window
            // (If you want to ensure full cleanup, use driver.quit();)
        }
    }

    // ---------- helpers ----------

    private WebElement findFirstPresentAndVisible(List<By> locators, Duration timeout) {
        long end = System.nanoTime() + timeout.toNanos();
        NoSuchElementException last = null;

        for (;;) {
            for (By by : locators) {
                try {
                    WebElement e = driver.findElement(by);
                    if (e != null) {
                        // ensure visible
                        if (isVisible(e)) return e;
                    }
                } catch (NoSuchElementException ignored) {
                    last = ignored;
                }
            }
            if (System.nanoTime() > end) {
                throw (last != null ? last :
                        new NoSuchElementException("None of locators matched within timeout: " + locators));
            }
            try { Thread.sleep(250); } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new RuntimeException(ie);
            }
        }
    }

    private boolean isVisible(WebElement e) {
        try {
            return wait.until(ExpectedConditions.visibilityOf(e)) != null;
        } catch (Exception ex) {
            return false;
        }
    }
}