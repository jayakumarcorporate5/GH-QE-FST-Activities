package TesttNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class actTestng7 {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Create a Firefox driver instance
        driver = new FirefoxDriver();
        // Open the login page
        driver.get("https://training-support.net/webelements/login-form");
    }

    // DataProvider returning 2 sets (username, password)
    @DataProvider(name = "Authentication")
    public Object[][] credentials() {
        return new Object[][]{
                { "admin1", "password1" },
                { "wrongAdmin", "wrongPassword" }
        };
    }

    // Test method consuming the DataProvider
    @Test(dataProvider = "Authentication")
    public void loginTest(String username, String password) {
        // Find username and password fields (findElement as per activity)
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement submitBtn     = driver.findElement(By.xpath("//button[text()='Submit']"));

        // Clear and enter values
        usernameField.clear();
        usernameField.sendKeys(username);

        passwordField.clear();
        passwordField.sendKeys(password);

        // Click Login
        submitBtn.click();

        // The activity does not require assertions; just demonstrate data-driven inputs.
        // If you want to validate, you can add an assertion later based on the result page.
    }

    @AfterClass
    public void tearDown() {
        // Close the browser once tests are done
        if (driver != null) {
            driver.close();
        }
    }
}