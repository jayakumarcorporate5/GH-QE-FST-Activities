package TesttNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class actTestng6 {

    WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Create Firefox driver
        driver = new FirefoxDriver();

        // Open the login page
        driver.get("https://training-support.net/webelements/login-form");
    }

    @Test
    @Parameters({ "username", "password" })
    public void loginTest(String username, String password) {

        // Find all input fields and button using findElements()
        List<WebElement> inputs = driver.findElements(By.cssSelector("input"));
        WebElement loginButton = driver.findElement(By.xpath("//button[text()='Submit']"));

        // Enter username and password
        inputs.get(0).sendKeys(username);
        inputs.get(1).sendKeys(password);

        // Click login
        loginButton.click();
    }

    @AfterClass
    public void tearDown() {
        // Close the browser
        driver.close();
    }
}