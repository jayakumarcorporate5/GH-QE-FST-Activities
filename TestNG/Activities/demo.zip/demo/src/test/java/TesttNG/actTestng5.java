package TesttNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class actTestng5 {

    WebDriver driver;

    @BeforeClass(alwaysRun = true)
    public void setUp() {
        driver = new FirefoxDriver();
        driver.get("https://training-support.net/webelements/target-practice");
    }

    // ✅ No groups here, so it won't be excluded by group filters
    @Test
    public void pageTitleTest() {
        String title = driver.getTitle();
        System.out.println("Page Title: " + title);
        Assert.assertEquals(title, "Selenium: Target Practice");
    }

    // ---------------- HEADER TESTS ----------------
    @Test(dependsOnMethods = "pageTitleTest", groups = "HeaderTests")
    public void headerTest1() {
        WebElement header3 = driver.findElement(By.xpath("//h3[contains(@class,'orange')]"));
        Assert.assertEquals(header3.getText(), "Heading #3");
    }

    @Test(dependsOnMethods = "pageTitleTest", groups = "HeaderTests")
    public void headerTest2() {
        String cssColor = driver.findElement(By.cssSelector("h5.text-purple-600"))
                .getCssValue("color");
        Color header5Color = Color.fromString(cssColor);
        Assert.assertEquals(header5Color.asHex(), "#9333ea");
    }

    // ---------------- BUTTON TESTS ----------------
    @Test(dependsOnMethods = "pageTitleTest", groups = "ButtonTests")
    public void buttonTest1() {
        WebElement emeraldButton = driver.findElement(By.xpath("//button[contains(@class,'emerald')]"));
        Assert.assertEquals(emeraldButton.getText(), "Emerald");
    }

    @Test(dependsOnMethods = "pageTitleTest", groups = "ButtonTests")
    public void buttonTest2() {
        WebElement purpleButton = driver.findElement(By.xpath("//button[contains(@class,'purple')]"));
        String bgColorRaw = purpleButton.getCssValue("background-color");
        Color bgColor = Color.fromString(bgColorRaw);
        System.out.println("Purple button background-color (raw): " + bgColorRaw);
        System.out.println("Purple button background-color (hex): " + bgColor.asHex());
        Assert.assertEquals(bgColor.asHex(), "#6b21a8", "Background color mismatch");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.close();
        }
    }
}