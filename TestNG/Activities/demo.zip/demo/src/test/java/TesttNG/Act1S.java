// package TesttNG;

// import org.openqa.selenium.By;
// import org.openqa.selenium.WebDriver;
// import org.openqa.selenium.firefox.FirefoxDriver;
// import org.testng.Assert;
// import org.testng.annotations.AfterClass;
// import org.testng.annotations.BeforeClass;
// import org.testng.annotations.Test;

// public class Act1S {
//     WebDriver driver;
    
//     // Setup function
//     @BeforeClass
//     public void setUp() {
//         // Initialize Firefox driver
//         driver = new FirefoxDriver();
//         // Open the page
//         driver.get("https://training-support.net");
//     }
    
//     // Test function
//     @Test(priority = 1)
//     public void homePageTest() {
//         // Assert page title
//         Assert.assertEquals(driver.getTitle(), "Training Support");
        
//         // Find and click the About page link
//         driver.findElement(By.linkText("About Us")).click();
//     }
    
//     @Test(priority = 2)
//     public void aboutPageTest() {
//         // Assert page title
//         Assert.assertEquals(driver.getTitle(), "About Training Support");
//     }
    
//     // Teardown function
//     @AfterClass
//     public void tearDown() {
//         // Close the browser
//         driver.quit();
//     }
// }

package TesttNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class Act1S {
    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // ❌ No System.setProperty here
        driver = new FirefoxDriver();  // Selenium Manager will resolve geckodriver
        driver.get("https://training-support.net");
    }

    @Test(priority = 1)
    public void homePageTest() {
        Assert.assertEquals(driver.getTitle(), "Training Support");
        driver.findElement(By.linkText("About Us")).click();
        new WebDriverWait(driver, Duration.ofSeconds(10))
                .until(ExpectedConditions.titleIs("About Training Support"));
    }

    @Test(priority = 2, dependsOnMethods = "homePageTest")
    public void aboutPageTest() {
        Assert.assertEquals(driver.getTitle(), "About Training Support");
    }

    @AfterClass(alwaysRun = true)
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}