public class hello {
    public static void main(String[] args) {
		
        System.out.println("Hello, World!");
        String name = "Ram";
        System.out.println(name);
 
    }

}
