package activity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class RandomScannerActivity {
    public static void main(String[] args) {
        // Create the required objects
        Scanner scan = new Scanner(System.in);
        List<Integer> list = new ArrayList<>();
        Random indexGen = new Random();

        System.out.println("Enter integers (non-integer or EOF to stop):");

        // Accept only integers, keep reading while the next token is an int
        while (scan.hasNextInt()) {
            list.add(scan.nextInt());
        }

        // Close scanner (good practice)
        scan.close();

        // Convert the ArrayList to an array
        Integer[] nums = list.toArray(new Integer[0]);

        // Handle edge case: no numbers entered
        if (nums.length == 0) {
            System.out.println("No integers were entered. Exiting.");
            return;
        }

        // Generate a random index within bounds [0, nums.length)
        int idx = indexGen.nextInt(nums.length);

        // Print the generated index and the value at that index
        System.out.println("Random index generated: " + idx);
        System.out.println("Value at that index: " + nums[idx]);

        // (Optional) Show the whole list for clarity
        System.out.println("All numbers: " + list);
    }
}