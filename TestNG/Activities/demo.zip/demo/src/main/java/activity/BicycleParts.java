package activity;

public interface BicycleParts {
    public int tyres = 2;     // number of tyres on the bicycle
    public int maxSpeed = 25; // max speed of the bicycle
}
