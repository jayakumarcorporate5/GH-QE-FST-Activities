package activity;

import java.util.HashSet;
import java.util.Set;

public class Activity10 {
    public static void main(String[] args) {
        // 1) Create a HashSet named hs
        Set<String> hs = new HashSet<>();

        // 2) Add 6 objects using add()
        System.out.println("Adding elements:");
        System.out.println("add(\"Apple\")  -> " + hs.add("Apple"));
        System.out.println("add(\"Banana\") -> " + hs.add("Banana"));
        System.out.println("add(\"Cherry\") -> " + hs.add("Cherry"));
        System.out.println("add(\"Date\")   -> " + hs.add("Date"));
        System.out.println("add(\"Elder\")  -> " + hs.add("Elder"));
        System.out.println("add(\"Fig\")    -> " + hs.add("Fig"));

        // 3) Print the size of the HashSet
        System.out.println("\nSize after adds: " + hs.size());

        // 4) Remove an element that exists
        System.out.println("\nremove(\"Cherry\") -> " + hs.remove("Cherry"));

        // 5) Try to remove an element that is not present
        System.out.println("remove(\"Grape\")   -> " + hs.remove("Grape"));

        // 6) Use contains() to check presence
        System.out.println("\ncontains(\"Apple\") -> " + hs.contains("Apple"));
        System.out.println("contains(\"Cherry\") -> " + hs.contains("Cherry"));

        // 7) Print the updated set
        System.out.println("\nUpdated set contents: " + hs);

        // (Optional) Show isEmpty() when we clear
        System.out.println("\nClearing set...");
        hs.clear();
        System.out.println("isEmpty() -> " + hs.isEmpty());
        System.out.println("Size -> " + hs.size());
    }
}