package activity;

import java.util.HashMap;
import java.util.Map;

public class Activity11 {
    public static void main(String[] args) {

        // 1) Create a Map with integer keys and String values
        Map<Integer, String> colours = new HashMap<>();

        // 2) Add 5 random colours
        colours.put(1, "Red");
        colours.put(2, "Blue");
        colours.put(3, "Green");
        colours.put(4, "Yellow");
        colours.put(5, "Violet");

        System.out.println("Initial Map: " + colours);

        // 3) Remove one colour
        System.out.println("Removing key 3 -> " + colours.remove(3));  // removes Green

        // 4) Try removing a colour that does NOT exist
        System.out.println("Removing key 10 -> " + colours.remove(10)); // null (not found)

        // 5) Check if Green exists
        System.out.println("Contains value \"Green\"? -> " + colours.containsValue("Green"));
        System.out.println("Contains value \"Blue\"?  -> " + colours.containsValue("Blue"));

        // 6) Print size of the map
        System.out.println("Size of map: " + colours.size());

        // 7) Print updated map
        System.out.println("Updated Map: " + colours);
    }
}