package activity;

public class Activity5 {
    public static void main(String[] args) {

        // Create an object of MyBook class
        MyBook newNovel = new MyBook();

        // Set title
        String title = "Harry Potter";  // you can change this
        newNovel.setTitle(title);

        // Print result
        System.out.println("The title is: " + newNovel.getTitle());
    }
}