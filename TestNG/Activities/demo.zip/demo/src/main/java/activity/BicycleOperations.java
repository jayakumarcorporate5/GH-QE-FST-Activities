package activity;

public interface BicycleOperations {
    public void applyBrake(int decrement); // reduce speed
    public void speedUp(int increment);    // increase speed
}