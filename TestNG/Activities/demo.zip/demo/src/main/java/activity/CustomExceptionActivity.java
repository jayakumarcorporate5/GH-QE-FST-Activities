package activity;

public class CustomExceptionActivity {

    /**
     * If value is null, throw CustomException.
     * Otherwise, print the value.
     */
    public static void exceptionTest(String value) throws CustomException {
        if (value == null) {
            throw new CustomException("Custom Error: value cannot be null");
        } else {
            System.out.println(value);
        }
    }

    public static void main(String[] args) {
        try {
            // Call with non-null - should print
            CustomExceptionActivity.exceptionTest("Will print to console");

            // Call with null - should throw and be caught below
            CustomExceptionActivity.exceptionTest(null);

            // (This line won't run because the second call throws)
            System.out.println("Done");
        } catch (CustomException e) {
            // Print the custom error message
            System.out.println("Caught exception → " + e.getMessage());
        }
    }
}