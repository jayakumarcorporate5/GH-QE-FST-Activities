package activity;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

public class RPSGame {

    // Enum for valid choices
    enum Choice {
        ROCK, PAPER, SCISSORS;

        // Determine if this beats the other
        boolean beats(Choice other) {
            return (this == ROCK && other == SCISSORS) ||
                   (this == PAPER && other == ROCK) ||
                   (this == SCISSORS && other == PAPER);
        }

        // Parse user input safely (accepts words or numbers)
        static Choice fromInput(String token) {
            if (token == null) return null;
            token = token.trim().toLowerCase();
            switch (token) {
                case "r":
                case "1":
                case "rock":      return ROCK;
                case "p":
                case "2":
                case "paper":     return PAPER;
                case "s":
                case "3":
                case "scissors":  return SCISSORS;
                default:          return null;
            }
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Rock • Paper • Scissors ===");
        System.out.println("Type your choice as: rock/paper/scissors (or 1/2/3 or r/p/s).");
        System.out.println("Type 'q' to quit at any time.\n");

        Random random = new Random();

        int userWins = 0, compWins = 0, draws = 0;

        // Try-with-resources ensures Scanner is closed automatically
        try (Scanner sc = new Scanner(System.in)) {
            gameLoop:
            while (true) {
                try {
                    // Prompt user input
                    System.out.print("Your move [rock/paper/scissors | 1/2/3 | r/p/s | q=quit]: ");
                    String token = sc.nextLine(); // may throw NoSuchElementException on EOF

                    if (token == null) {
                        System.out.println("\nNo input detected. Exiting.");
                        break;
                    }
                    token = token.trim();

                    // Quit option
                    if (token.equalsIgnoreCase("q") || token.equalsIgnoreCase("quit")) {
                        System.out.println("\nThanks for playing!");
                        break;
                    }

                    // Parse user choice
                    Choice userChoice = Choice.fromInput(token);
                    if (userChoice == null) {
                        System.out.println("❌ Invalid choice. Please enter rock/paper/scissors or 1/2/3 or r/p/s.");
                        continue; // ask again
                    }

                    // Generate computer choice
                    Choice[] values = Choice.values();
                    Choice compChoice = values[random.nextInt(values.length)];

                    System.out.println("You chose:      " + userChoice);
                    System.out.println("Computer chose: " + compChoice);

                    // Decide result
                    if (userChoice == compChoice) {
                        System.out.println("Result: 🤝 Draw!");
                        draws++;
                    } else if (userChoice.beats(compChoice)) {
                        System.out.println("Result: ✅ You win this round!");
                        userWins++;
                    } else {
                        System.out.println("Result: ❌ Computer wins this round!");
                        compWins++;
                    }

                    // Ask to play again
                    System.out.print("Play again? (y/n): ");
                    String again = sc.nextLine();
                    if (!again.equalsIgnoreCase("y") && !again.equalsIgnoreCase("yes")) {
                        break gameLoop;
                    }
                    System.out.println();

                } catch (InputMismatchException e) {
                    // This would happen if using nextInt and the user typed text.
                    System.out.println("Input error: please enter valid text or numbers. " + e.getMessage());
                    sc.nextLine(); // clear buffer if needed
                } catch (NoSuchElementException e) {
                    // End-of-input (Ctrl+D / Ctrl+Z) or stream closed
                    System.out.println("\nInput closed. Exiting the game.");
                    break;
                } catch (IllegalStateException e) {
                    System.out.println("Scanner is closed unexpectedly. Exiting.");
                    break;
                } catch (Exception e) {
                    // Catch-all for unexpected issues
                    System.out.println("Unexpected error: " + e.getMessage());
                }
            }
        }

        // Final scoreboard
        System.out.println("\n=== Final Score ===");
        System.out.println("You: " + userWins + " | Computer: " + compWins + " | Draws: " + draws);
        if (userWins > compWins) {
            System.out.println("🏆 You won the game! GG!");
        } else if (userWins < compWins) {
            System.out.println("🤖 Computer won the game. Better luck next time!");
        } else {
            System.out.println("⚖️ It's a tie overall!");
        }
    }
}