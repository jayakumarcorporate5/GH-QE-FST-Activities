// File: activity/DemoFunctionalInterface.java
package activity;

@FunctionalInterface
interface FuncInterfaceExample {
    String display(String str);
}

public class DemoFunctionalInterface {
    public static void main(String[] args) {
        FuncInterfaceExample obj = (String str) -> str;
        System.out.println(obj.display("Hello"));
    }
}