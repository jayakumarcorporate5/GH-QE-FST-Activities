package activity;

public class MountainBike extends Bicycle {

    public int seatHeight;

    // Use super to pass gears and currentSpeed; also set seatHeight
    public MountainBike(int gears, int currentSpeed, int startHeight) {
        super(gears, currentSpeed);
        this.seatHeight = startHeight;
    }

    public void setHeight(int newValue) {
        seatHeight = newValue;
    }

    // Override description to add seat height
    @Override
    public String bicycleDesc() {
        return super.bicycleDesc() + "\nSeat height is " + seatHeight;
    }
}