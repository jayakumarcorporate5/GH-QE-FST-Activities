package activity;

public class Bicycle implements BicycleParts, BicycleOperations {

    public int gears;
    public int currentSpeed;

    // Constructor initializes gears and currentSpeed
    public Bicycle(int gears, int currentSpeed) {
        this.gears = gears;
        this.currentSpeed = currentSpeed;
    }

    // Implement operations
    @Override
    public void applyBrake(int decrement) {
        currentSpeed -= decrement;
        System.out.println("Current speed: " + currentSpeed);
    }

    @Override
    public void speedUp(int increment) {
        currentSpeed += increment;
        System.out.println("Current speed: " + currentSpeed);
    }

    // Description method
    public String bicycleDesc() {
        return ("No of gears are " + gears + "\nSpeed of bicycle is " + maxSpeed);
    }
}
