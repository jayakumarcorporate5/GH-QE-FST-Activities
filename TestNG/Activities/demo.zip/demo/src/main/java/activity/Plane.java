package activity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Encapsulated Plane class.
 * - Keeps fields private
 * - Exposes behavior via methods
 * - Avoids direct field mutation from outside
 */
public class Plane {
    // Private fields (encapsulation)
    private List<String> passengers;
    private int maxPassengers;
    // Keeping the assignment's original (typo) name to match it exactly
    private Date lastTimeTookOf;   // time of last take-off
    private Date lastTimeLanded;   // time of last landing

    // Constructor: initializes maxPassengers and passengers list
    public Plane(int maxPassengers) {
        this.maxPassengers = maxPassengers;
        this.passengers = new ArrayList<>();
    }

    // Add a single passenger (uses List.add())
    public void onboard(String passenger) {
        if (passengers.size() >= maxPassengers) {
            System.out.println("Cannot onboard " + passenger + ": plane is full (" + maxPassengers + ").");
            return;
        }
        passengers.add(passenger);
    }

    // Record and return the take-off timestamp
    public Date takeOff() {
        lastTimeTookOf = new Date(); // current date/time
        return lastTimeTookOf;
    }

    // Record landing time and clear the passenger list
    public void land() {
        lastTimeLanded = new Date(); // current date/time
        passengers.clear();
    }

    // Getter: last landing time
    public Date getLastTimeLanded() {
        return lastTimeLanded;
    }

    // Getter: return a COPY of the passengers to preserve encapsulation
    public List<String> getPassengers() {
        return new ArrayList<>(passengers);
    }

    // (Optional) A couple of extra safe getters if you need them later
    public int getMaxPassengers() {
        return maxPassengers;
    }

    public Date getLastTimeTookOf() {
        return lastTimeTookOf;
    }
}