package activity;

public class Activity12 {
    public static void main(String[] args) {

        // ad1: lambda expression (no explicit body/braces/return)
        // Uses type inference for parameters.
        Addable ad1 = (a, b) -> (a + b);

        // ad2: lambda function with a body (braces + return + explicit types)
        Addable ad2 = (int a, int b) -> {
            return (a + b);
        };

        // Use the lambdas
        int sum1 = ad1.add(10, 15);
        int sum2 = ad2.add(7, 8);

        System.out.println("Sum using ad1 (lambda expression): " + sum1);
        System.out.println("Sum using ad2 (lambda function):   " + sum2);

        // (Optional) You can also create lambdas inline without variables:
        int sum3 = ((Addable) ((x, y) -> x + y)).add(100, 200);
        System.out.println("Sum using inline lambda:           " + sum3);
    }
}