package activity;

import java.util.Date;

public class Activity6 {
    public static void main(String[] args) {
        // Create a plane that can carry up to 10 passengers
        Plane plane = new Plane(10);

        // Onboard passengers
        plane.onboard("Alice");
        plane.onboard("Bob");
        plane.onboard("Charlie");

        // Take off and print the time
        Date takeOffTime = plane.takeOff();
        System.out.println("Take-off time: " + takeOffTime);

        // Print passengers currently onboard
        System.out.println("Passengers onboard: " + plane.getPassengers());

        // Emulate flight time (sleep for 5 seconds)
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            // If sleep is interrupted, reset the interrupt flag and continue
            Thread.currentThread().interrupt();
            System.out.println("Sleep interrupted.");
        }

        // Land the plane
        plane.land();

        // Print landing time and confirm passengers list is cleared
        System.out.println("Landing time: " + plane.getLastTimeLanded());
        System.out.println("Passengers after landing: " + plane.getPassengers());
    }
}