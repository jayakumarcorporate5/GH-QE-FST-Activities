package activity;

/**
 * Custom exception that carries a message provided by the caller.
 */
public class CustomException extends Exception {
    // Private message to store the custom error message
    private final String message;

    // Constructor to initialize the custom message
    public CustomException(String message) {
        this.message = message;
    }

    // Return the custom message when getMessage() is called
    @Override
    public String getMessage() {
        return message;
    }
}