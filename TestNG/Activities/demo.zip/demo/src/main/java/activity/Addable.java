package activity;

/**
 * Functional interface with a single abstract method (SAM).
 * This enables using lambdas and method references.
 */
@FunctionalInterface
public interface Addable {
    int add(int num1, int num2);
}