package activity;

public class Activity2 {

    // Helper method: returns true if the sum of all 10's is exactly 30
    public static boolean isSumOfTensThirty(int[] numbers) {
        int sum = 0;
        for (int n : numbers) {
            if (n == 10) {
                sum += 10;
            }
        }
        return sum == 30;
    }

    public static void main(String[] args) {
        // Initialize the array with 6 numbers
        int[] nums = {10, 77, 10, 54, -11, 10};

        // Check condition and print result
        boolean result = isSumOfTensThirty(nums);
        System.out.println("Sum of all 10's is exactly 30: " + result);
    }
}